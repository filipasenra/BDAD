.mode       columns
.headers    on
.nullvalue  NULL

SELECT * 
FROM Funcionario
WHERE codigo = 2019001;

UPDATE HORARIO
SET prevencao = 1
WHERE codigo=1;


SELECT * 
FROM Funcionario
WHERE codigo = 2019001;