.mode       columns
.headers    on
.nullvalue  NULL

 SELECT marca
   FROM Veiculo
 WHERE disponivel = 1;
